//
//  ViewController.swift
//  calculator
//
//  Created by 李以謙 on 2022/3/21.
//

import UIKit

var currentNumber:String = "0"
var CLabelText:String = ""
var opChangeLabelText:String = ""
var numberList:Array<Double> = []
var opList:Array<Character> = []
var isOperating = false
var isFloat = false

let ORANGE = #colorLiteral(red: 0.9441747069, green: 0.5805539489, blue: 0.2003090978, alpha: 1)
let WHITE = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
let BLACK = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)

enum opType{
    case add
    case sub
    case mul
    case div
    case none
}

var operation:opType = .none


class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var clearButton: UIButton!
    
    @IBOutlet weak var selectedButton: UIButton!
    
    @IBOutlet weak var test: UILabel!
    
//    @IBOutlet weak var plusButton: UIButton!
//    @IBOutlet weak var minusButton: UIButton!
//    @IBOutlet weak var mulButton: UIButton!
//    @IBOutlet weak var divButton: UIButton!
//
//    private func restoreOpButtonColor(){
//        plusButton.setTitleColor(BLACK, for: .normal)
//        plusButton.backgroundColor = ORANGE
//        minusButton.setTitleColor(BLACK, for: .normal)
//        minusButton.backgroundColor = ORANGE
//        mulButton.setTitleColor(BLACK, for: .normal)
//        mulButton.backgroundColor = ORANGE
//        divButton.setTitleColor(BLACK, for: .normal)
//        divButton.backgroundColor = ORANGE
//    }
    
    @IBAction func div(_ sender: UIButton) {
        operation = .div
        isOperating = true
        opList.append("÷")
        numberList.append(Double(currentNumber) ?? Double(0))
        label.text = ""
        for i in 0...(opList.count-1) {
            label.text = label.text! + "\(numberList[0])" + "\(opList[i])"
        }
        currentNumber = "0"
        clearButton.setTitle("C", for: .normal)
        isFloat = false
//
//        restoreOpButtonColor()
        selectedButton = sender
        sender.setTitleColor(ORANGE, for: .normal)
        sender.backgroundColor = WHITE
    }
    
    @IBAction func mul(_ sender: UIButton) {
        label.text = label.text! + "×"
        operation = .mul
        isOperating = true
        opList.append("×")
        numberList.append(Double(currentNumber) ?? Double(0))
        
        label.text = ""
        for i in 0...(opList.count-1) {
            label.text = label.text! + "\(numberList[0])" + "\(opList[i])"
        }
        currentNumber = "0"
        clearButton.setTitle("C", for: .normal)
        isFloat = false
//
//        restoreOpButtonColor()
        selectedButton = sender
        sender.setTitleColor(ORANGE, for: .normal)
        sender.backgroundColor = WHITE
    }
    
    @IBAction func sub(_ sender: UIButton) {
        label.text = label.text! + "-"
        operation = .sub
        isOperating = true
        opList.append("-")
        numberList.append(Double(currentNumber) ?? Double(0))
        
        label.text = ""
        for i in 0...(opList.count-1) {
            label.text = label.text! + "\(numberList[0])" + "\(opList[i])"
        }
        currentNumber = "0"
        clearButton.setTitle("C", for: .normal)
        isFloat = false
//
//        restoreOpButtonColor()
        selectedButton = sender
        sender.setTitleColor(ORANGE, for: .normal)
        sender.backgroundColor = WHITE
    }
    
    @IBAction func add(_ sender: UIButton) {
        label.text = label.text! + "+"
        operation = .add
        isOperating = true
        opList.append("+")
        numberList.append(Double(currentNumber) ?? Double(0))
        
        label.text = ""
        for i in 0...(opList.count-1) {
            label.text = label.text! + "\(numberList[0])" + "\(opList[i])"
        }
        
        currentNumber = "0"
        clearButton.setTitle("C", for: .normal)
        isFloat = false
//
//        restoreOpButtonColor()
        selectedButton = sender
        sender.setTitleColor(ORANGE, for: .normal)
        sender.backgroundColor = WHITE
    }
    
    @IBAction func getResult(_ sender: UIButton) {
        var temp:Double = 0
        var answer:Double = 0
        if Double(currentNumber) == 0 {
            result.text = "0"
        } else {
            numberList.append(Double(currentNumber) ?? Double(0))
            
            if opList.count > 0 {
                for i in 0...(opList.count-1) {
                    if opList[i] == "×" {
                        temp = numberList[i] * numberList[i+1]
                        if i>0 && opList[i-1] == "-" {
                            opList[i] = "-"
                        } else {
                            opList[i] = "+"
                        }
                        numberList[i+1] = temp
                        numberList[i] = 0
                    } else if opList[i] == "÷" {
                        temp = numberList[i]/numberList[i+1]
                        if i>0 && opList[i-1] == "-" {
                            opList[i] = "-"
                        } else {
                            opList[i] = "+"
                        }
                        
                        numberList[i+1] = temp
                        numberList[i] = 0
                    }
                }
            }
            
            answer = numberList[0]
            
            
            if opList.count > 0 {
                for _ in 0...(opList.count-1) {

                    if opList[0] == "+" {
                        answer += numberList[1]
                        opList.removeFirst()
                        numberList.removeFirst()
                    } else {
                        answer -= numberList[1]
                        opList.removeFirst()
                        numberList.removeFirst()
                    }
                }
            }
            
            
            result.text = "\(answer)"
        }
        numberList.removeAll()
        operation = .none
        label.text = "0"
        currentNumber = "0"
        numberList.removeAll()
        opList.removeAll()
        isOperating = false
        isFloat = false
        clearButton.setTitle("AC", for: .normal)
        selectedButton.setTitleColor(BLACK, for: .normal)
        selectedButton.backgroundColor = ORANGE
    }
    
    @IBAction func number(_ sender: UIButton) {
        let inputNumber = sender.tag - 1
        if label.text != nil {
            if label.text == "0" {
                label.text =  "\(inputNumber)"
                currentNumber = "\(inputNumber)"
            } else {
                label.text =  label.text! + "\(inputNumber)"
                currentNumber = currentNumber + "\(inputNumber)"
            }
            
        }
    }
    
    
    @IBAction func dot(_ sender: UIButton) {
        if (isFloat == false) {
            label.text = label.text! + "."
            currentNumber = currentNumber + "."
            isFloat = true
        }
    }
    
    @IBAction func clear(_ sender: UIButton) {
        if sender.currentTitle! == "C" {
            label.text = "0"
            currentNumber = "0"
            isFloat = false
            label.text = ""
            for i in 0...(opList.count-1) {
                label.text = label.text! + "\(numberList[i])" + "\(opList[i])"
            }
            sender.setTitle("AC", for: .normal)
            
        } else {
            label.text = "0"
            operation = .none
            result.text = "0"
            currentNumber = "0"
            numberList.removeAll()
            opList.removeAll()
            isOperating = false
            isFloat = false
            selectedButton.setTitleColor(BLACK, for: .normal)
            selectedButton.backgroundColor = ORANGE
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

